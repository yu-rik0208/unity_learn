using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OffsetPosition : MonoBehaviour
{
    private float randomX;
    private float randomZ;
    public Transform target;
    public Vector3 offset;
    public GameObject field;

    void Start()
    {
        StartCoroutine("GetCloser");
    }

    IEnumerator GetCloser()
    {
        while (true)
        {
          
            randomX = Random.Range(-1, 1);
            randomZ = Random.Range(-1, 1);
            offset = new Vector3(randomX, 0, randomZ);
            this.transform.position = target.position + offset;
            yield return new WaitForSeconds(1.0f);
        }
    }
}