using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Navigoal : MonoBehaviour
{
    NavMeshAgent agent;
    public GameObject target;

    // Use this for initialization
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();//アタッチされているNavMeshAgentを取得
        agent.SetDestination(target.transform.position);
    }


    private void Update()
    {
        agent.SetDestination(target.transform.position);
    }

}
