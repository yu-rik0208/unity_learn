using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class FloorChange : MonoBehaviour
{
    private GameObject[] targets; // 目的地
    private int nextIndex = 0; //次の目的地のインデックス
    private NavMeshAgent agent; //自動で動くオブジェクト

    public GameObject target_I;
    public GameObject target_II;


    void Start()
    {
        // アタッチされているオブジェクトのNaveMeshAgentを取得
        agent = GetComponent<NavMeshAgent>();

        // 目的地情報の取得(順番通りに取得できるわけではない)
        //targets = GameObject.FindGameObjectsWithTag("target");

        // 最初の目的地を設定
        //agent.destination = targets[nextIndex].transform.position;

        agent.SetDestination(target_I.transform.position);
    }

    void OnCollisionEnter(Collision other)
    {

        // 衝突対象が目的地のピラーだったら次の目的地を設定する
        if (other.gameObject.tag == "Target1")
        {

            /*次の目的地のインデックスにする
            if (nextIndex < targets.Length - 1)
            {
                nextIndex++;
            }
            else
            {
                nextIndex = 0;
            }*/

            // インデックスに応じた目的地を設定する
            //agent.destination = targets[nextIndex].transform.position;
            agent.SetDestination(target_II.transform.position);

        }

    }

    /*void Update()
    {
        NavMeshAgent nav_mesh_agent = GetComponent<NavMeshAgent>();
        if (nav_mesh_agent.remainingDistance == 0.0f)
        {
            //GetComponent<Animator>().SetBool("Win", true);
            agent.SetDestination(target_II.transform.position);
        }
        else
        {
            GetComponent<Animator>().SetFloat("Speed", nav_mesh_agent.velocity.magnitude);
        }
    }*/


}
